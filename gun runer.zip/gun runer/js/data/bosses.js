/* ============================================================
   GUN RUNNER
   BOSS DATA
============================================================ */

const BOSS_DATA = {

    SCRAP_TITAN: {
        id: "scrap_titan",
        name: "SCRAP TITAN",

        maxHealth: 5000,

        phaseCount: 3,

        radius: 3.8,

        moveSpeed: 1.2,

        contactDamage: 35,

        reward: 1000,

        color: 0x777777,

        phases: [

            {
                healthThreshold: 0.70,

                attackInterval: 2.5,

                attacks: [
                    "slam",
                    "charge",
                    "summon"
                ]
            },

            {
                healthThreshold: 0.40,

                attackInterval: 1.8,

                attacks: [
                    "slam",
                    "charge",
                    "summon",
                    "projectile"
                ]
            },

            {
                healthThreshold: 0,

                attackInterval: 1.2,

                attacks: [
                    "charge",
                    "summon",
                    "projectile",
                    "rage"
                ]
            }

        ]
    },


    VOID_BEAST: {
        id: "void_beast",
        name: "VOID BEAST",

        maxHealth: 7500,

        phaseCount: 3,

        radius: 4.5,

        moveSpeed: 1.5,

        contactDamage: 45,

        reward: 1500,

        color: 0x6633aa,

        phases: [

            {
                healthThreshold: 0.70,

                attackInterval: 2.4,

                attacks: [
                    "claw",
                    "summon"
                ]
            },

            {
                healthThreshold: 0.40,

                attackInterval: 1.7,

                attacks: [
                    "claw",
                    "dash",
                    "summon",
                    "void_orb"
                ]
            },

            {
                healthThreshold: 0,

                attackInterval: 1.0,

                attacks: [
                    "dash",
                    "void_orb",
                    "summon",
                    "rage"
                ]
            }

        ]
    },


    WAR_MACHINE: {
        id: "war_machine",
        name: "WAR MACHINE",

        maxHealth: 10000,

        phaseCount: 4,

        radius: 5.0,

        moveSpeed: 1.0,

        contactDamage: 55,

        reward: 2500,

        color: 0xcc3333,

        phases: [

            {
                healthThreshold: 0.75,

                attackInterval: 2.5,

                attacks: [
                    "machine_gun",
                    "missile"
                ]
            },

            {
                healthThreshold: 0.50,

                attackInterval: 2.0,

                attacks: [
                    "machine_gun",
                    "missile",
                    "summon"
                ]
            },

            {
                healthThreshold: 0.25,

                attackInterval: 1.5,

                attacks: [
                    "missile",
                    "laser",
                    "summon"
                ]
            },

            {
                healthThreshold: 0,

                attackInterval: 0.9,

                attacks: [
                    "laser",
                    "missile",
                    "machine_gun",
                    "rage"
                ]
            }

        ]
    },


    DRAGON_CORE: {
        id: "dragon_core",
        name: "DRAGON CORE",

        maxHealth: 15000,

        phaseCount: 4,

        radius: 5.5,

        moveSpeed: 1.3,

        contactDamage: 70,

        reward: 5000,

        color: 0xff5522,

        phases: [

            {
                healthThreshold: 0.75,

                attackInterval: 2.4,

                attacks: [
                    "fireball",
                    "wing_attack"
                ]
            },

            {
                healthThreshold: 0.50,

                attackInterval: 1.9,

                attacks: [
                    "fireball",
                    "wing_attack",
                    "summon"
                ]
            },

            {
                healthThreshold: 0.25,

                attackInterval: 1.4,

                attacks: [
                    "fireball",
                    "meteor",
                    "summon"
                ]
            },

            {
                healthThreshold: 0,

                attackInterval: 0.8,

                attacks: [
                    "meteor",
                    "fireball",
                    "wing_attack",
                    "rage"
                ]
            }

        ]
    },


    FINAL_OVERLORD: {
        id: "final_overlord",
        name: "THE OVERLORD",

        maxHealth: 30000,

        phaseCount: 5,

        radius: 6.5,

        moveSpeed: 1.1,

        contactDamage: 100,

        reward: 10000,

        color: 0xff2244,

        phases: [

            {
                healthThreshold: 0.80,

                attackInterval: 2.5,

                attacks: [
                    "laser",
                    "summon"
                ]
            },

            {
                healthThreshold: 0.60,

                attackInterval: 2.0,

                attacks: [
                    "laser",
                    "missile",
                    "summon"
                ]
            },

            {
                healthThreshold: 0.40,

                attackInterval: 1.5,

                attacks: [
                   